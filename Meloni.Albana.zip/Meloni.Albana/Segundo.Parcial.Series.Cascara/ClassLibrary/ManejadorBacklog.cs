﻿using System;
using System.Buffers;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public delegate void DelegadoBacklog(Serie serie);
    public class ManejadorBacklog
    {
        public event DelegadoBacklog NuevaSerieParaVer;

        public void IniciarManejador(List<Serie> series)
        {
            Task task = new Task(() =>
            {
                MoverSeries(series);
                Thread.Sleep(1500);
            });
            task.Start();
        }
        private void MoverSeries(List<Serie> series)
        {
            List<int> indices = new List<int>();

            for (int i = 0; i < series.Count; i++)
            {
                int indice = series.GenerarRandom();
                while (indices.Contains(indice))
                {
                    indice = series.GenerarRandom();
                }
                NuevaSerieParaVer?.Invoke(series[indice]);
                AccesoDatos.ActualizarSerie(series[indice]);
            }
        }
    }
}

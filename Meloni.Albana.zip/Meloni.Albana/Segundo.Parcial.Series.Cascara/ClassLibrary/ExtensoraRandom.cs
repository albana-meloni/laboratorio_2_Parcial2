﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class ExtensoraRandom
    {
        public static int GenerarRandom(this List<Serie> lista)
        {
            int numeroRandom = new Random().Next(0, lista.Count - 1);

            return numeroRandom;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class AccesoDatos
    {
        static SqlConnection conexion;
        static SqlCommand comando;

        static AccesoDatos()
        {
            conexion = new SqlConnection(@"Data Source = .;
                                Database = 20240701-SP;
                                Trusted_Connection = True;");
            comando = new SqlCommand();
        }

        public static void ActualizarSerie(Serie item)
        {
            try
            {
                comando.CommandText = $"UPDATE series SET alumno = 'Albana'";
                comando.Connection = conexion;

                conexion.Open();
                comando.ExecuteNonQuery();
            }
            finally
            {
                if (conexion != null && conexion.State == System.Data.ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
        }

        public static List<Serie> ObtenerBackLog()
        {
            List<Serie> listaSeries = new List<Serie>();

            string select = "SELECT * FROM series";

            comando.CommandText = select;
            comando.Connection = conexion;

            conexion.Open();
            SqlDataReader reader = comando.ExecuteReader();

            while (reader.Read())
            {
                string nombre = reader["nombre"] != DBNull.Value ? (string)reader["nombre"] : "";
                string genero = reader["genero"] != DBNull.Value ? (string)reader["genero"] : "";

                Serie serie = new Serie(genero, nombre);

                listaSeries.Add(serie);
            }
            reader.Close();
            conexion.Close();

            return listaSeries;
        }
    }
}

﻿using System.Text;

namespace ClassLibrary
{
    public class Serie
    {
        string genero;
        string nombre;

        public Serie()
        {
            
        }
        public Serie(string genero, string nombre) :this()
        {
            Genero = genero;
            Nombre = nombre;
        }

        public string Genero { get => genero; set => genero = value; }
        public string Nombre { get => nombre; set => nombre = value; }

        public override string ToString()
        {
            return $"{Nombre} - {Genero}";
        }
    }
}

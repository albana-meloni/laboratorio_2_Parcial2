﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class Logger
    {
        public static void Log(string mensaje)
        {
            try
            {
                string pathArchivo = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "directorio/log.txt");

                using (TextWriter writer = new StreamWriter(pathArchivo, true))
                {
                    writer.WriteLine($"{mensaje} - {DateTime.Now:g}");
                }
            }
            catch (Exception ex)
            {

                throw new BackLogException("Error al crear el archivo log.txt", ex);
            }

        }
    }
}

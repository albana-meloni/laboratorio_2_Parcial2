using ClassLibrary;

namespace TestProject
{
    [TestClass]
    public class TestUnitarios
    {
        [TestMethod]
        public void Serializar_CuandoLePasoUnaLista_SeCreanLosArchivosXmlYJson()
        {
            // arrange
            List<Serie> backlog = new List<Serie> { new Serie("sitcom", "the office"), new Serie("drama", "bridgerton") };

            Serializadora serializadora = new Serializadora();


            // act
            string rutaXml = Path.Combine(Directory.GetCurrentDirectory(), "prueba.xml");
            serializadora.Guardar(backlog, rutaXml);

            string rutaJson = Path.Combine(Directory.GetCurrentDirectory(), "prueba.json");
            ((IGuardar<List<Serie>>)serializadora).Guardar(backlog, rutaJson);


            // assert
            Assert.IsTrue(File.Exists(rutaXml));
            Assert.IsTrue(File.Exists(rutaJson));

            if (File.Exists(rutaXml) && File.Exists(rutaJson))
            {
                File.Delete(rutaXml);
                File.Delete(rutaJson);
            }
        }

        [TestMethod]
        public void ProbarExcepcion_CuandoNoTienePath_SaltaExcepcionBacklog()
        {
            // arrange
            List<Serie> backlog = new List<Serie> { new Serie("sitcom", "the office"), new Serie("drama", "bridgerton") };

            Serializadora serializadora = new Serializadora();
            string rutaXml = "";

            try
            {
                // act
                serializadora.Guardar(backlog, rutaXml);
            }
            catch (BackLogException ex)
            {
                // assert
                StringAssert.Contains(ex.Message, "Error al guardar las series en formato XML");
            }
        }
    }
}